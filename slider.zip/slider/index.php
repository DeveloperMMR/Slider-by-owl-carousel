<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="css/all.min.css">
<link rel="stylesheet" type="text/css" href="css/fontawesome.min.css">
<link rel="stylesheet" type="text/css" href="css/normalize.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="css/owl.theme.default.min.css">
<link rel="stylesheet" type="text/css" href="css/owl.theme.green.min.css">




<div class="slider owl-carousel">
	<div class="item1 first">
		<h1>MD MohaiMinur rahman Mukta</h1>
		<p>Hy, I am professioanl website back-end and font-end developer. I am Expert in PHP and Java programing language also with python language. Your can visit all of my git project for checking my skill. I never get payid before complete project. You can contact with me for more discuss <br>Thank You</p>

		<a href="https://www.fiverr.com/mohaiminur24?up_rollout=true">Contact with me</a>
	</div>

	<div class="item1 secound">	
		<ul>
			<li><a href="https://www.facebook.com/developermmr"><i class="fa-brands fa-facebook-square"></i></a></li>
			<li><a href="https://www.instagram.com/mohaiminur_mmr/"><i class="fa-brands fa-instagram-square"></i></a></li>
			<li><a href="https://www.linkedin.com/in/mohaiminur-rahman-mukta-b26855108/"><i class="fa-brands fa-linkedin"></i></a></li>
			<li><a href="https://twitter.com/MuktaMohaiminur"><i class="fa-brands fa-twitter-square"></i></a></li>
			<li><a href="https://www.fiverr.com/mohaiminur24?up_rollout=true"><i class="fa-solid fa-address-card"></i></a></li>
			<li><a href="https://github.com/DeveloperMMR"><i class="fa-brands fa-git-square"></i></a></li>
		</ul>

		<p>
			Your can contact with us by this platfrom.
		</p>

	</div>

	<div class="item1 third">
		<div class="third_part">
			<ul>
			<li><i class="fa-solid fa-code"></i>HTML(Hyper text Markup Language)</li>
			<li><i class="fa-solid fa-code"></i>CSS(Cascading style sheet)</li>
			<li><i class="fa-solid fa-code"></i>Bootstrap</li>
			<li><i class="fa-solid fa-code"></i>MySQL Database</li>
			<li><i class="fa-solid fa-code"></i>JavaScript</li>
			<li><i class="fa-solid fa-code"></i>PHP Language</li>
			<li><i class="fa-solid fa-code"></i>Python Language</li>
			<li><i class="fa-solid fa-code"></i>Laravel Framwork</li>
			<li><i class="fa-solid fa-code"></i>React</li>
			<li><i class="fa-solid fa-code"></i>nodeJS</li>
			<li><i class="fa-solid fa-code"></i>Angular</li>
			<li><i class="fa-solid fa-code"></i>REST And APIs</li>
			<li><i class="fa-solid fa-code"></i>Django</li>
			<li><i class="fa-solid fa-code"></i>MongoDB</li>
			<li><i class="fa-solid fa-code"></i>Server Maintaince</li>
			<li><i class="fa-solid fa-code"></i>Docker</li>
		</ul>
		</div>
		
		</div>
	
</div>











<script type="text/javascript" src="js/all.min.js"></script>
<script type="text/javascript" src="js/fontawesome.min.js"></script>
<script type="text/javascript" src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript">
	$('.owl-carousel').owlCarousel({
    loop:true,
    nav:true,
    items:1,
    autoplay: true,
    smartSpeed: 2000,
    autoplayHoverPause: true,
    
})

</script>